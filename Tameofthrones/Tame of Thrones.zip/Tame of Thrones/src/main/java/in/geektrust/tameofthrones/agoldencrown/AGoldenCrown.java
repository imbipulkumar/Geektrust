package in.geektrust.tameofthrones.agoldencrown;

/**
* Interface for A Golden Crown.
* 
*/
public interface AGoldenCrown {

    /**
    * Output the Ruler and allies kingdoms.
    * 
    */
    public void ruler();
    
}